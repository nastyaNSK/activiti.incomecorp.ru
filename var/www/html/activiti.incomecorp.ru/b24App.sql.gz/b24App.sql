-- MySQL dump 10.13  Distrib 5.7.38-41, for Linux (x86_64)
--
-- Host: localhost    Database: b24App
-- ------------------------------------------------------
-- Server version	5.7.38-41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50717 SELECT COUNT(*) INTO @rocksdb_has_p_s_session_variables FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' AND TABLE_NAME = 'session_variables' */;
/*!50717 SET @rocksdb_get_is_supported = IF (@rocksdb_has_p_s_session_variables, 'SELECT COUNT(*) INTO @rocksdb_is_supported FROM performance_schema.session_variables WHERE VARIABLE_NAME=\'rocksdb_bulk_load\'', 'SELECT 0') */;
/*!50717 PREPARE s FROM @rocksdb_get_is_supported */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
/*!50717 SET @rocksdb_enable_bulk_load = IF (@rocksdb_is_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @rocksdb_dummy_bulk_load = 0') */;
/*!50717 PREPARE s FROM @rocksdb_enable_bulk_load */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;

--
-- Table structure for table `QueryCounter`
--

DROP TABLE IF EXISTS `QueryCounter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QueryCounter` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` varchar(516) COLLATE utf8_unicode_ci NOT NULL,
  `client_endpoint` varchar(516) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `activiti_code` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `run_count` int(10) unsigned NOT NULL DEFAULT '0',
  `mount` int(10) unsigned NOT NULL DEFAULT '0',
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QueryCounter`
--

LOCK TABLES `QueryCounter` WRITE;
/*!40000 ALTER TABLE `QueryCounter` DISABLE KEYS */;
INSERT INTO `QueryCounter` VALUES (4,'303e5e2e760d8d6195dc4c3d545ced3b','','A.DELAY_BIZ',11,0,'2023-02-26 10:44:04'),(5,'303e5e2e760d8d6195dc4c3d545ced3b','','A.TASKS_ADD_COMMENT',1,0,'2023-02-26 09:33:23'),(6,'303e5e2e760d8d6195dc4c3d545ced3b','','A.DEAL_BACK_STAGE',9,0,'2023-02-26 10:44:04'),(7,'303e5e2e760d8d6195dc4c3d545ced3b','','R.DELAY_BIZ',1,0,'2023-02-27 05:31:30'),(8,'86d76c948321d1389643bff2ccfb4363','','R.TASKS_ADD_COMMENT',391,0,'2023-06-01 07:00:04'),(9,'fabb96671bd7d5908b86bb10f3c7e947','','A.TASKS_ADD_COMMENT',62,0,'2023-05-17 13:54:18'),(10,'e4e4158528e6735f7b7947cda5f82af0','','R.TASKS_ADD_COMMENT',219,0,'2023-06-19 11:52:47'),(11,'c39a0e12c694649669a86be68fe2944a','','A.DELAY_BIZ',8,0,'2023-04-03 10:35:22'),(12,'c39a0e12c694649669a86be68fe2944a','','R.DELAY_BIZ',12,0,'2023-04-03 10:35:24'),(13,'e4e4158528e6735f7b7947cda5f82af0','','A.TASKS_STATUS',576,0,'2023-06-05 10:23:21'),(14,'1b29dc0f6ac025ea0884019722ca9cc8','','A.TASKS_RENEW',1,0,'2023-05-04 12:52:16'),(15,'e4e4158528e6735f7b7947cda5f82af0','','R.TASKS_STATUS',93,0,'2023-05-24 06:51:23'),(16,'e4e4158528e6735f7b7947cda5f82af0','','A.TASKS_RENEW',5,0,'2023-05-25 03:37:13'),(17,'4b047021c6c82fa957118fd9a9421f7e','','R.TASKS_ADD_COMMENT',9,0,'2023-05-31 08:02:29'),(18,'2c5bfa88468f60580c28951a961a5ebb','','A.DEAL_SEARCH',3,0,'2023-06-06 10:10:26'),(19,'2c5bfa88468f60580c28951a961a5ebb','','R.DEAL_SEARCH',3,0,'2023-06-07 05:07:34'),(20,'2c5bfa88468f60580c28951a961a5ebb','','A.LEAD_SEARCH',2,0,'2023-06-07 05:25:24'),(21,'4402fec7c5d9cc6c049298879c362c28','','A.DEAL_SEARCH',27,0,'2023-06-08 09:40:19'),(22,'e4e4158528e6735f7b7947cda5f82af0','','A.TASKS_ADD_COMMENT',16,0,'2023-06-20 08:10:42'),(23,'280b11895643d718e4bc29f797d90bfc','','R.CONTACT_SEARCH',29,0,'2023-06-20 11:53:42'),(24,'ce881ffc5c0021f8e0dfc5f2040fafd2','','A.CONTACT_SEARCH',154,0,'2023-06-14 13:22:11'),(25,'280b11895643d718e4bc29f797d90bfc','','A.CONTACT_SEARCH',7,0,'2023-06-14 13:24:05'),(26,'ce881ffc5c0021f8e0dfc5f2040fafd2','','R.CONTACT_SEARCH',8,0,'2023-06-15 09:04:54'),(27,'ce881ffc5c0021f8e0dfc5f2040fafd2','','R.LEAD_SEARCH',7,0,'2023-06-16 09:26:43');
/*!40000 ALTER TABLE `QueryCounter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appScopes`
--

DROP TABLE IF EXISTS `appScopes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appScopes` (
  `oAuthId` int(10) unsigned NOT NULL,
  `scopeId` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appScopes`
--

LOCK TABLES `appScopes` WRITE;
/*!40000 ALTER TABLE `appScopes` DISABLE KEYS */;
/*!40000 ALTER TABLE `appScopes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oAuth`
--

DROP TABLE IF EXISTS `oAuth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oAuth` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `access_token` varchar(256) NOT NULL,
  `expires` timestamp NOT NULL,
  `expires_in` int(10) unsigned NOT NULL,
  `domain` varchar(516) NOT NULL,
  `server_endpoint` varchar(516) NOT NULL,
  `status` varchar(16) NOT NULL,
  `client_endpoint` varchar(516) NOT NULL,
  `member_id` varchar(516) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `refresh_token` varchar(516) NOT NULL,
  `application_token` varchar(516) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oAuth`
--

LOCK TABLES `oAuth` WRITE;
/*!40000 ALTER TABLE `oAuth` DISABLE KEYS */;
INSERT INTO `oAuth` VALUES (1,'a71e8064005de3be005f9a0c0000000140380737cddfae8f31b88f6f9c4e02f79e0afa','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','S','https://work.income-media.ru/rest/','2c5bfa88468f60580c28951a961a5ebb',1,'979da764005de3be005f9a0c0000000140380736c52786a1cd2edcd451b2c6bcb3ce26','00d5375eff9ba65ed52dd98c66647b0b'),(2,'2a19a863005de3be005fce3200000001403807c9d8fbc9c659123c3d5da52c3291c52c','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','P','https://b24-23xjqv.bitrix24.ru/rest/','bc61c980b760cd125696f7afd257891b',1,'1a98cf63005de3be005fce3200000001403807fe0a5c88693e67c7a686c4d424dd0b4f','93f4b730916528485d9ab133a9d7bd21'),(3,'789ba463005de3be00598ad60000000100000730387e9aa8453d961146b5395660647d','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','P','https://mood24.bitrix24.ru/rest/','de9c95a615a1eca4c1ace3cec7984cb6',1,'681acc63005de3be00598ad600000001000007ddba951c2c1ddb5dc2f39a4a3df17714','13a2b7865c716f7a7aeb139ec79ed913'),(4,'f482a963005de3be005598580000000c4038078be4ebd920e18c35a40a5e3076672583','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','S','https://cppkdpo.bitrix24.ru/rest/','e600a4a1a11e7a1a87be8aafbbe640d6',12,'e401d163005de3be005598580000000c403807226364c64ed8ef47a9f078d1cb43d771','da1f2b8226c558cbad525cb4ec1d6dad'),(5,'f9e69364005de3be003e1b48000006ef403807a8ee38934b85e0710b74d148c011a67f','0000-00-00 00:00:00',3600,'tehnoopt.bitrix24.ru','','S','https://tehnoopt.bitrix24.ru/rest/','8258497882767dd02e4570128b4d1740',0,'e965bb64005de3be003e1b48000006ef40380754710a2caf2bde33cdd9077a817ba043','8769e1652bc57614621665013d7a34b9'),(6,'c543a563005de3be005567ce0000142000000783c455e54f38cc60f5e2e9e376917730','0000-00-00 00:00:00',3600,'pravo.moepravo.pro','','S','https://pravo.moepravo.pro/rest/','8a930c910acfba3fcb6be40af283f13f',0,'b5c2cc63005de3be005567ce00001420000007941c5ccbdcb7179d09a582b7b88d237b','5da1d0debe1e457ccd7f768f454097e0'),(7,'c860a563005de3be00576740000000480000071adb4399a2aa32ea37db3f47a8be4c77','0000-00-00 00:00:00',3600,'webmens2.bitrix24.ru','','S','https://webmens2.bitrix24.ru/rest/','4c6d9843d735d9f3d493387cae18c39d',0,'b8dfcc63005de3be005767400000004800000763fbadecb049a58a5ab74edebe8c007a','66bb84ab0e41b1d2443ccc382effd500'),(8,'9f8e8164005de3be003bbd1a00000001000007529b1d6e52b59e2aeeac0881254d4720','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','S','https://handle.bitrix24.ru/rest/','77db65a5ee698c9a5ea635a9cc67e839',1,'8f0da964005de3be003bbd1a00000001000007441e284ddf3d639909f09f852561f4f7','420125d8c434df9a8907a8f76c12c81a'),(9,'586da863005de3be0060202400000001000007f738de32125834a6c66ae9ba5d49d6fd','0000-00-00 00:00:00',3600,'b24-zc607n.bitrix24.ru','','S','https://b24-zc607n.bitrix24.ru/rest/','fde60db5b988c884357c82aee0abf099',0,'48eccf63005de3be0060202400000001000007f1ea5b9510644db8f3210ec97a664648','69a4fddd72afdd20312d415a07fac7d5'),(10,'f267c263005de3be005758060000a1dd0000072f98bc8c8c2a5f3c70b832805f1379a2','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','S','https://bitrix.nebojump.ru/rest/','a03c8d6a3ab1479801a16a73e44c2590',41437,'e2e6e963005de3be005758060000a1dd000007946c74c7d51d78c85dbb3ad45c7b5d83','4a84852a4f34764570d884ab8dc834e5'),(11,'0cd8aa63005de3be005cf426000000240000073956739e0e0c0a3ebf39170f2d475fcc','0000-00-00 00:00:00',3600,'b24-xgruzx.bitrix24.ru','','S','https://b24-xgruzx.bitrix24.ru/rest/','d16eca24dcc448866f63fb877608a077',0,'fc56d263005de3be005cf426000000240000076d20bba6a286f83c6e6b30b22b251a95','7bea5c1b4e633a2ae77f760566704a2e'),(12,'83edaa63005de3be003223580000007e4038072d69fc34a6b18f1fa1fda871f0aea1b3','0000-00-00 00:00:00',3600,'ablok.bitrix24.ru','','S','https://ablok.bitrix24.ru/rest/','1287790c15578bd0f3b378f4d272a715',0,'736cd263005de3be003223580000007e4038075207825d1119c76096abad04bbde77a4','7a04a8a121bb3650b872d9bdca6a238e'),(13,'867db463005de3be00604d0400000001f0f1072f60fff12624b0459a1cc97de9c28ade','0000-00-00 00:00:00',3600,'b24-t8ey4x.bitrix24.ru','','S','https://b24-t8ey4x.bitrix24.ru/rest/','675ef3f290ee518e616adee0a4fa9775',0,'76fcdb63005de3be00604d0400000001f0f1077f375ec21c741aec7b6f9a9ab0ffce77','b1f01ffac09a168751bf41755b2e8173'),(14,'9af8bb63005de3be003971a000001758000007132625ccf5901a1af89cd85e4903902e','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','S','https://nedor-mebel.bitrix24.ru/rest/','9ed536d857ed30ca94a6085cebcdcd70',5976,'8a77e363005de3be003971a00000175800000710fc83aeffd9d216d99551d55ee27c38','ce3538605606866a7d610760571ea3de'),(15,'ebfdb763005de3be006017e00000000100000757cf6a093333c01c781dbd51a9cb2f82','0000-00-00 00:00:00',3600,'b24.fedostsev.ru','','S','https://b24.fedostsev.ru/rest/','cd37e77901f5a81ad93924fc6811d744',0,'db7cdf63005de3be006017e000000001000007483a36f59c6c5bc7608441052579a537','3250e6d9e7815e62b399a3c4627b27c3'),(16,'05507864005de3be00467c8a0000005f000007905645db3121eb72510004387ea3443f','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','S','https://avtotcifra.bitrix24.ru/rest/','86d76c948321d1389643bff2ccfb4363',95,'f5ce9f64005de3be00467c8a0000005f00000790dbe2e5adc4e927e7dd9e787ced2e2e','b53b8efbb997f2bb1fabd7086c510b36'),(17,'aa1af563005de3be005eea1c00000001000007b1ebed54e133aefc85be9c0fe46362dd','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','S','https://b24-i6j65h.bitrix24.ru/rest/','c89ef37946a688ad6b59bb1a0c865ea9',1,'9a991c64005de3be005eea1c000000010000078f5f55cb39bf27a6fbe9d96f80b56204','78706f1fccb1a7293b57a01a685e98d5'),(18,'474efc63005de3be0061756c000000014038074c7fe7d4edf2d3f0ec4d1b1044d445df','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','S','https://b24-hwza1s.bitrix24.ru/rest/','303e5e2e760d8d6195dc4c3d545ced3b',1,'37cd2364005de3be0061756c00000001403807a665da38fdc9a05b2e19248b277c6c5f','fe62b146cf6d1c8b35433d111ae0ff5a'),(19,'17c60064005de3be004b054e00001cf6000007fa679a83a7be2e142afcd3a146374f37','0000-00-00 00:00:00',3600,'hr-link.bitrix24.ru','','S','https://hr-link.bitrix24.ru/rest/','f6890297a8fe778297f34940fe02881f',0,'07452864005de3be004b054e00001cf60000074a025a0eb94a468265946b21bcac0bda','9e705746c3fa85753866374920a6ba6d'),(20,'14ea6464005de3be00568c1e000004e900000733dd1587d68e7207806a69900b0da0bf','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','S','https://portal.dostaevsky.ru/rest/','fabb96671bd7d5908b86bb10f3c7e947',1257,'04698c64005de3be00568c1e000004e9000007641deddd291efee0bba4d2960fa47cab','5e1f25504210fa617f7f60f67d31c0c1'),(21,'c3689164005de3be0052b30000000028403807fa1d5d2ef0bf973bd2853f357ad363be','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','S','https://crm.gk-arsa.ru/rest/','e4e4158528e6735f7b7947cda5f82af0',40,'b3e7b864005de3be0052b3000000002840380712bacd00f6d97bff9b72dc797d356139','80105d0150a3fd67acd4ca3ea17c4dc7'),(22,'bc592164005de3be005e95ca00000005000007449411ab06b9a146cfe520be30596416','0000-00-00 00:00:00',3600,'spg24.ru','','S','https://spg24.ru/rest/','78716f957dc1fc1dffdbc441b3f5c52b',0,'acd84864005de3be005e95ca00000005000007c01310f8ea32ed3c01aa0223d785dbcb','bf738c8833e9a417369c0f1a883b0d7d'),(23,'f8762564005de3be005ea5e00000002c000007fb5c81827fabecaa473c86b96e078616','0000-00-00 00:00:00',3600,'bitrix.ntcfenix.ru','','S','https://bitrix.ntcfenix.ru/rest/','590522d476347cba91b1d766038660d0',0,'e8f54c64005de3be005ea5e00000002c000007a639e9556c3567c6a0e8b845f2410d8f','539ddc37b1a25565d212a2c726c4f969'),(24,'8db02a64005de3be005f7d40000000460000071df8db85636e860db3f18bab34e93596','0000-00-00 00:00:00',3600,'markbarton.bitrix24.ru','','S','https://markbarton.bitrix24.ru/rest/','c39a0e12c694649669a86be68fe2944a',0,'7d2f5264005de3be005f7d4000000046000007cc699c07aed7bfd386955f400c2657de','35c5fc3ed4d273c4a08ea9ca037794d8'),(25,'d81d5164005de3be006372aa0000000140380754a912097f64599f0b709db90d39883b','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','S','https://b24-qpuitr.bitrix24.ru/rest/','b5429f0ed54d860c6b073c1898198a7c',1,'c99c7864005de3be006372aa00000001403807ca9b6dc8af4d88be56d7416b2536c51f','4289bed7cbc7248fab94168328eb19cf'),(26,'5bb65364005de3be003b3b7000000001000007d4140b3e73eed96a871d7750583d9038','0000-00-00 00:00:00',3600,'crmprogress.bitrix24.ru','','S','https://crmprogress.bitrix24.ru/rest/','1b29dc0f6ac025ea0884019722ca9cc8',0,'4b357b64005de3be003b3b700000000100000734f80cc69a2e07742b4ba28b7744c7c0','4e63222743fc486e9358ec37f10ee8e7'),(27,'f0e06d64005de3be0063d82a000000014038073b0064409da7fbb96cb840b12737af15','0000-00-00 00:00:00',3600,'b24-3z5tow.bitrix24.ru','','S','https://b24-3z5tow.bitrix24.ru/rest/','ab0fd342c9712db6502b1c8e4b1687e2',0,'e05f9564005de3be0063d82a00000001403807fbed34a7c3c812ad89e01d464d2c1e94','85facfb1289a5c794171d39d3cd799e3'),(28,'9e848864005de3be006155fa00000001000007288a2542f9f215a9e055260806aeacd4','0000-00-00 00:00:00',3600,'kmnd.bitrix24.ru','','S','https://kmnd.bitrix24.ru/rest/','4b047021c6c82fa957118fd9a9421f7e',0,'8e03b064005de3be006155fa00000001000007f1ad6628b6323b266b279b5a3d7be498','08d1314d21b8e120a674ccf7667b7954'),(29,'7dc87c64005de3be005f82740000000100000739fa078127fbab62cea6c960c1303aed','0000-00-00 00:00:00',3600,'graalgroup.bitrix24.ru','','S','https://graalgroup.bitrix24.ru/rest/','6138c08457409a2e247299d921a0022a',0,'6d47a464005de3be005f82740000000100000720f253f13a97c5b47d8bdd7211e36370','fcab4eda17b6b912812ea647f8c1f7e4'),(30,'e8a98164005de3be0064605e0000000140380763f852e24608e1651c61e02cfae0630c','0000-00-00 00:00:00',3600,'b24-sl0jov.bitrix24.ru','','S','https://b24-sl0jov.bitrix24.ru/rest/','4402fec7c5d9cc6c049298879c362c28',0,'d828a964005de3be0064605e00000001403807e0477cb6b56317f6e5b6722066db2dff','49d2fd42684c2a347e86a087f1b996f4'),(31,'66a19164005de3be00400c7c000006ca40380707a91418ed04c48c617cddb3718c1c19','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','S','https://b24-interval.ru/rest/','280b11895643d718e4bc29f797d90bfc',1738,'5620b964005de3be00400c7c000006ca403807fead8bf25e787b5195248cdfedfca568','f85c19dba7d05c25627ebac530118ce4'),(32,'10a18864005de3be00645a660000005f000007404e440cefcbe6f195fb6625044857ff','0000-00-00 00:00:00',3600,'portal.i-box.company','','S','https://portal.i-box.company/rest/','996af3876bbaa9e3bdbd738e2bcbb514',0,'0020b064005de3be00645a660000005f0000072a00bc874c8069c3cd5f449e38e30cc8','1f9ac8dd341a9bf99bba24d468f87b80'),(33,'ee388c64005de3be0064786e000000014038077651ab40c5f9b32a950656fa18287d70','0000-00-00 00:00:00',3600,'oauth.bitrix.info','https://oauth.bitrix.info/rest/','S','https://b24-mt610y.bitrix24.ru/rest/','ce881ffc5c0021f8e0dfc5f2040fafd2',1,'deb7b364005de3be0064786e0000000140380761e4c9be2d8b87f65c50528427492c63','8da34e23fc43ad99ec54da16b9210a2a'),(34,'c1c38964005de3be0022f2640000016900000738a5b6a75174e670825d2655316c0719','0000-00-00 00:00:00',3600,'irts.bitrix24.ru','','S','https://irts.bitrix24.ru/rest/','b7385ab4ea5d1c7a8915d6f893cfbe1f',0,'b142b164005de3be0022f2640000016900000776467a5a552296b2396074f0d8097299','5e29ddbef9a5b35dcd275935091f9c6b');
/*!40000 ALTER TABLE `oAuth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scope`
--

DROP TABLE IF EXISTS `scope`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scope` (
  `scopeId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `scopeName` varchar(32) NOT NULL,
  PRIMARY KEY (`scopeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scope`
--

LOCK TABLES `scope` WRITE;
/*!40000 ALTER TABLE `scope` DISABLE KEYS */;
/*!40000 ALTER TABLE `scope` ENABLE KEYS */;
UNLOCK TABLES;
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-22  9:35:18
